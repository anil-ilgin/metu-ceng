
Java source code of the Image Generator application
is included for the interested.
